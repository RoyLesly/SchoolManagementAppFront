import React from 'react'

const PageDashboardLecturer = () => {
  return (
    <div>DASHBOARD LECTURER</div>
  )
}

export default PageDashboardLecturer