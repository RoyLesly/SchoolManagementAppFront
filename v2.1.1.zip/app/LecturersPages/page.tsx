import React from 'react';
import PageDashboardLecturer from './PageDashboardLecturer/page';

const page = () => {
  return (
    <PageDashboardLecturer />
  )
}

export default page;