import React from 'react'
import PageSettings from './PageSettings'

const page = () => {
  return (
    <PageSettings />
  )
}

export default page