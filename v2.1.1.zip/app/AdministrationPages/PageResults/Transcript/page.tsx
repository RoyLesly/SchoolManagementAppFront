import MyReactTanstackTable from '@/Designs/MyReactTable'
import React from 'react'

const page = () => {
  return (
    <div>
      <MyReactTanstackTable />
    </div>
  )
}

export default page