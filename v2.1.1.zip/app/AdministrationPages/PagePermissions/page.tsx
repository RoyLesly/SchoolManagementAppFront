import React from 'react'
import PagePermissions from './PagePermissions'

const page = () => {
  return (
    <PagePermissions />
  )
}

export default page