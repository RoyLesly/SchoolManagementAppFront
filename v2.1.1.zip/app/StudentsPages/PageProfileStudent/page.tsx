import AccountStudentProfileSettings from '@/components/CompAccountSettingsStudent/AccountProfileStudent'
import React, { FC } from 'react'


interface AccountSettingsProps {

}
const page = () => {

  return (
    <AccountStudentProfileSettings />
  )
}

export default page