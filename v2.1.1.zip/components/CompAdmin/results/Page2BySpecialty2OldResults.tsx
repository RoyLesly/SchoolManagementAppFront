import React from 'react'

const Page2BySpecialty2OldResults = () => {
  return (
    <div>Page2BySpecialty2OldResults</div>
  )
}

export default Page2BySpecialty2OldResults