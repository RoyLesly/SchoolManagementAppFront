'use client';
import {
    Typography, Box,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    Chip
} from '@mui/material';
import DashboardCard from '@/components/CompAdmin/shared/DashboardCard';
import { nowYear } from '@/Utils/constants';
import { useEffect, useState } from 'react';
import { MainSpecialtyProps, SpecialtyProps, UserProfile } from '@/Utils/types';
import { getAllMainSpecialties, getAllSpecialties, getAllUserProfiles } from '@/Utils/functions';

const products = [
    {
        id: "1",
        name: "Sunil Joshi",
        post: "Web Designer",
        pname: "Elite Admin",
        priority: "Low",
        pbg: "primary.main",
        budget: "3.9",
    },
    {
        id: "2",
        name: "Andrew McDownland",
        post: "Project Manager",
        pname: "Real Homes WP Theme",
        priority: "Medium",
        pbg: "secondary.main",
        budget: "24.5",
    },
    {
        id: "3",
        name: "Christopher Jamil",
        post: "Project Manager",
        pname: "MedicalPro WP Theme",
        priority: "High",
        pbg: "error.main",
        budget: "12.8",
    },
    {
        id: "4",
        name: "Nirav Joshi",
        post: "Frontend Engineer",
        pname: "Hosting Press HTML",
        priority: "Critical",
        pbg: "success.main",
        budget: "2.4",
    },
];


const ProductPerformance = () => {
    const Yaxis = Array(nowYear - (nowYear - 6)).fill('').map((v, index) => nowYear - index).reverse()
    const [ mainSpecialty, setMainSpecialty ] = useState<MainSpecialtyProps[]>([])
    const [ profiles, setProfiles ] = useState<UserProfile[]>([])
    const [ count, setCount ] = useState<number>(1)

    useEffect(() => {
        if (count == 1) {
            console.log(count, 1)
            getAllMainSpecialties(setMainSpecialty, ()=>{})
            if (mainSpecialty.length > 0) { setCount(count + 1); }
        }
        if (count == 2) {
            console.log(count, 2)
            getAllUserProfiles(setProfiles, ()=>{}, { searchField: "role", value: "student" })
            setCount(count + 1);
        }
        if (count == 3) {
            console.log(count, 3)
            const d = []
            if (mainSpecialty.length > 0) {
                const record = {}
                // const p = for (let index = 0; index < mainSpecialty.length; index++) {
                //     const ms = mainSpecialty[index];
                //     const prof = profiles.filter((item: UserProfile) => item?.specialty?.main_specialty.id == ms.id);
                //     return 0
                // }
                // console.log(p)
                // const p = Yaxis.forEach(itemY => mainSpecialty.forEach(
                //     itemMS => profiles.filter(
                //         (itemProf: UserProfile) => itemProf?.specialty?.main_specialty.id == itemMS.id
                //         )
                //     ))
                // console.log(p)
                setCount(count + 1)
            }
        }
        if (count == 4) {
            console.log(count, 4)
            setCount(count + 1)
        }
    }, [count, Yaxis, mainSpecialty])
    // console.log(mainSpecialty)

    const column = [
        {
            id: "Specialty",
            name: "Specialty",
            width: 600
        }
    ]
    const data = [
        {
            id: "Specialty",
            name: "Specialty",
            width: 600
        }
    ]
    const c = Yaxis.map(item => column.push({
        id: item.toString(),
        name: item.toString(),
        width: 400
    }))
    // console.log(column)

    return (

        <DashboardCard title="Product Performance">
            <Box sx={{ overflow: 'auto', width: { xs: '280px', sm: 'auto' } }}>
                <Table
                    aria-label="simple table"
                    sx={{
                        whiteSpace: "nowrap",
                        mt: 2
                    }}
                >
                    <TableHead>
                        <TableRow>
                            {column.map((item) => (
                                <TableCell key={item.id}>
                                    <Typography variant="subtitle2" fontWeight={item.width}>
                                        {item.name}
                                    </Typography>
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {products.map((product) => (
                            <TableRow key={product.name}>
                                <TableCell>
                                    <Typography
                                        sx={{
                                            fontSize: "15px",
                                            fontWeight: "500",
                                        }}
                                    >
                                        {product.id}
                                    </Typography>
                                </TableCell>
                                <TableCell>
                                    <Box
                                        sx={{
                                            display: "flex",
                                            alignItems: "center",
                                        }}
                                    >
                                        <Box>
                                            <Typography variant="subtitle2" fontWeight={600}>
                                                {product.name}
                                            </Typography>
                                            <Typography
                                                color="textSecondary"
                                                sx={{
                                                    fontSize: "13px",
                                                }}
                                            >
                                                {product.post}
                                            </Typography>
                                        </Box>
                                    </Box>
                                </TableCell>
                                <TableCell>
                                    <Typography color="textSecondary" variant="subtitle2" fontWeight={400}>
                                        {product.pname}
                                    </Typography>
                                </TableCell>
                                <TableCell>
                                    <Chip
                                        sx={{
                                            px: "4px",
                                            backgroundColor: product.pbg,
                                            color: "#fff",
                                        }}
                                        size="small"
                                        label={product.priority}
                                    ></Chip>
                                </TableCell>
                                <TableCell align="right">
                                    <Typography variant="h6">${product.budget}k</Typography>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </Box>
        </DashboardCard>
    );
};

export default ProductPerformance;
