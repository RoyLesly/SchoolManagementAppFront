import AccountSettings from '@/components/CompAccountSettings/AccountProfile'
import React from 'react'

const Page = () => {

  return (
    <AccountSettings />
  )
}

export default Page