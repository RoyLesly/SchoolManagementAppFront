import React from 'react'
import TableProfiles from '../PageStudents/TableProfiles'

const page = () => {
  return (
    <TableProfiles userprofiletype='teacher' />
  )
}

export default page