import React from 'react'
import PageResults from './PageResults'

const page = () => {
  return (
    <PageResults />
  )
}

export default page