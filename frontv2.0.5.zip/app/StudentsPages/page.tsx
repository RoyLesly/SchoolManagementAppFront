import React from 'react'
import PageDashboardStudent from './PageDashboardStudent/page'

const page = () => {
  return (
    <PageDashboardStudent />
  )
}

export default page