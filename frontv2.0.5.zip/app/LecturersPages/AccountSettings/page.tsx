import AccountSettings from '@/components/CompAccountSettings/AccountProfile'
import React, { FC } from 'react'


interface AccountSettingsProps {

}
const page = () => {

  return (
    <AccountSettings />
  )
}

export default page