import React from 'react';
import AccountLecturerProfileSettings from '@/components/CompAccountSettingsLecturer/AccountProfileLecturer'

const page = () => {

  return (
    <AccountLecturerProfileSettings />
  )
}

export default page