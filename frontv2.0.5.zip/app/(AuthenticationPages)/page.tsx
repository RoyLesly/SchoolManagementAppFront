import React from 'react'
import LoginPage from './login/LoginPage'

const page = () => {
  return (
    <LoginPage />
  )
}

export default page