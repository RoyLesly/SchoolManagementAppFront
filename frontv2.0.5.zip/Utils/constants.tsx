export const nowYear = new Date().getUTCFullYear();
